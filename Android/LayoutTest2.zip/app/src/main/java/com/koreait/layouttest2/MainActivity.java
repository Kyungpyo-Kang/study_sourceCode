package com.koreait.layouttest2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

//  ImageView iv1, iv2;
//  boolean flag = true;

    ImageView[] imageViews = new ImageView[4];
    int index = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//      iv1 = findViewById(R.id.iv1);
//      iv2 = findViewById(R.id.iv2);

        for(int i = 0; i < imageViews.length; i++) {
            imageViews[i] = findViewById(R.id.iv1 + i);
//          Log.e("R.id.iv" + (i + 1), R.id.iv1 + i + "");
        }
    }

    public void changeImage(View view) {
        /*
        if(flag) {
            iv1.setVisibility(View.INVISIBLE);
            iv2.setVisibility(View.VISIBLE);
        } else {
            iv1.setVisibility(View.VISIBLE);
            iv2.setVisibility(View.INVISIBLE);
        }
        flag = !flag;
        */
//      FrameLayout의 모든 이미지를 숨긴다.
        for(int i = 0; i < imageViews.length; i++) {
            imageViews[i].setVisibility(View.INVISIBLE);
        }
//      표시할 이미지만 FrameLayout에 표시한다.
        /*
        if(++index == imageViews.length) {
            index = 0;
        }
        imageViews[index].setVisibility(View.VISIBLE);
        */
        imageViews[++index % imageViews.length].setVisibility(View.VISIBLE);
    }
}









