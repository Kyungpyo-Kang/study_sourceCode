package com.example.switchertest;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.ViewSwitcher;

public class MainActivity extends AppCompatActivity {

    TextSwitcher ts;
    String[] texts = {"Android", "JAVA", "Kotlin"};
    ImageSwitcher is;
    int[] images = {R.drawable.background, R.drawable.sample, R.drawable.sample_2};
    int idx = 0;
    float downX, upX;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ts = findViewById(R.id.ts);
        is = findViewById(R.id.is);

//      프로그램에서 TextSwitcher에 문자열을 표시하는 TextView를 ViewFactory 객체로 만들어 넣어준다.
        ts.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
//              TextSwitcher에 넣어줄 TextView를 만든다.
                TextView textView = new TextView(getApplicationContext());
//              필요하다면 TextView의 속성을 변경한다.
                textView.setTextSize(50.0f);
                textView.setTextColor(Color.MAGENTA);
                textView.setGravity(Gravity.CENTER);
                return textView;
            }
        });
//      TextSwitcher에 setText() 메소드로 표시할 문자열을 넣어준다.
        ts.setText(texts[idx]);

//      프로그램에서 ImageSwitcher에 이미지를 표시하는 ImageView를 ViewFactory 객체로 만들어 setFactory() 메소드로 넣어준다.
        is.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
//              ImageSwitcher에 넣어줄 ImageView를 만든다.
                ImageView imageView = new ImageView(getApplicationContext());
                return imageView;
            }
        });
//      ImageSwitcher에 setImageResource() 메소드로 표시할 그림을 넣어준다.
        is.setImageResource(images[idx]);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN) {
            downX = event.getX();
        } else if(event.getAction() == MotionEvent.ACTION_UP) {
            upX = event.getX();

            if(downX < upX) {

                idx = --idx < 0? texts.length-1:idx;

                ts.setInAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.left_in));
                ts.setOutAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.right_out));
                ts.setText(texts[idx]);
                is.setInAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.left_in));
                is.setOutAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.right_out));
                is.setImageResource(images[idx]);
            } else if(downX > upX) {

                idx = ++idx == texts.length? 0:idx;

                ts.setInAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.right_in));
                ts.setOutAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.left_out));
                ts.setText(texts[idx]);
                is.setInAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.right_in));
                is.setOutAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.left_out));
                is.setImageResource(images[idx]);

            }


        }
        return super.onTouchEvent(event);
    }
}









