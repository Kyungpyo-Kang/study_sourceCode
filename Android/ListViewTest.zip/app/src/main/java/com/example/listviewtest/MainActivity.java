package com.example.listviewtest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    String[] arData = {
            "데이터1","데이터2","데이터3","데이터4","데이터5","데이터6","데이터7","데이터8",
            "데이터9","데이터10","데이터11","데이터12","데이터13","데이터14","데이터15","데이터16",
            "데이터17","데이터18","데이터19","데이터20","데이터21","데이터22","데이터23","데이터24",

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);

//      ListView에 데이터를 넣어주려면 반드시 Adapter를 이용해서 데이터를 할당해야 한다.

//      배열이나 ArrayList와 같은 List 타입의 데이터(간단한 데이터)는 안드로이드에서 제공하는 ArrayAdapter를 사용한다.

//        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, Arrays.asList(arData));

        /*라디오버튼 구현*/
/*
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_single_choice, arData);
//      위와 같이 코딩하면 ListView에 라디오 버튼이 표시되지만 선택되지 않기 때문에 아래와 같이 ChoiceMode를 지정한다.
        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);    //  단일 선택 모드
*/
        /*체크박스 구현*/

/*
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_multiple_choice, arData);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);  //  다중 선택 모드
*/

        /*체크 구현*/
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_checked, arData);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);


//      ListView에 adapter를 넣어준다.
        listView.setAdapter(adapter);

//      ListView를 클릭했을 때 실행해야 할 동작이 있다면 OnItemClickListener를 걸어준다.
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), (position+1)+"번째 데이터 "+arData[position]+" 선택", Toast.LENGTH_SHORT).show();
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), (position+1)+"번째 데이터 길게 눌러서 선택", Toast.LENGTH_SHORT).show();
                return false;
            }
        });





    }
}







