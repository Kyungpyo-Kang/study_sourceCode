package com.example.listviewtest3;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

//  BaseAdpater 클래스를 상속받아 Adapter를 만들면 레이아웃을 전개하고 데이터를 넣어주는 기능을 하는 클래스와 Adapter를 만들어주는
//  클래스를 별도로 만들어 사용해야 하는 번거로움이 있었다.
//  ArrayAdapter 클래스를 상속받아 전개된 레이아웃을 ListView에 뿌려줄 내용을 저장하는 Adapter를 만든다.
//  =>  상속받는 ArrayAdapter 클래스의 제네릭에 반드시 ListView에 넣어줄 데이터를 저장하고 있는 클래스 이름을 적어야 한다.
public class ChunjaViewAdapter extends ArrayAdapter<Chunja> {

//  Context, 전개할 레이아웃의 id, ListView에 출력할 데이터를 저장할 멤버를 선언한다.
    Context context;
    int resource;
    List<Chunja> objects;


//  선언한 멤버를 초기화 시키는 생성자를 만든다.


    public ChunjaViewAdapter(Context context, int resource, List<Chunja> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
    }

//  getView() 메소드를 Override 해서 레이아웃을 전개하고 전개된 레이아웃에 데이터를 저장해서 리턴시킨다.


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

//      레이아웃을 View에 전개한다.
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(resource, parent, false);

//      ListView에 넣어줄 데이터를 얻어온다.
        Chunja chunja = objects.get(position);

//      View에 전개된 레이아웃의 위젯에 데이터를 넣어준다.
        TextView tv1 = view.findViewById(R.id.tv1);
        TextView tv2 = view.findViewById(R.id.tv2);
        TextView tv3 = view.findViewById(R.id.tv3);

        tv1.setText(chunja.getH());
        tv2.setText(chunja.getK());
        tv3.setText(chunja.getC());


//      return super.getView(position, convertView, parent);
//      ListView에 넣어줄 view를 리턴시킨다.
        return view;
    }

}











