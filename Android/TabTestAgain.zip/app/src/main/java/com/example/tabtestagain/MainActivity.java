package com.example.tabtestagain;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    TabLayout tab;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tab = findViewById(R.id.tab);
        viewPager = findViewById(R.id.viewPager);


        //  tab을 표시할 Adapter 내부 클래스 객체를 만들고 TabLayout과 ViewPager에 추가할 내용을 넣어준다.

        MainPagerAdapter adapter = new MainPagerAdapter(getSupportFragmentManager());

    //  ViewPager에 넣어줄 Fragment : app 폴더 우클릭 => New => Fragment => Fragment(Blank)

    //  ViewPager에 넣어줄 Fragment 객체를 생성한다.
        fragment1 frag1 = new fragment1();
        adapter.addItem("코딩이",frag1);
        fragment2 frag2 = new fragment2();
        adapter.addItem("역병이 돌고 있다.",frag2);
        fragment3 frag3 = new fragment3();
        adapter.addItem("주의",frag3);


//      ViewPager에 Adapter를 넣어준다.
        viewPager.setAdapter(adapter);

//      TabLayout을 활성화 시킨다.
        tab.setupWithViewPager(viewPager);


    }

//  TabLayout과 ViewPager에 추가할 내용을 넣어주는 내부클래스 FragmentPagerAdapter 클래스를 상속받아 만든다.
    class MainPagerAdapter extends FragmentPagerAdapter {
//      TabLayout에 표시될 데이터를 기억할 ArrayList
        ArrayList<String> title = new ArrayList<>();
//      VeiwPager에 표시될 Fragment를 기억할 ArrayList
        ArrayList<Fragment> item = new ArrayList<>();

        public MainPagerAdapter(@NonNull FragmentManager fm) {
            super(fm);
        }

        //여기부터
        //ViewPager에 전개될 Fragment를 얻어오는 메소드
        @NonNull
        @Override
        public Fragment getItem(int position) {
//            return null;를 아래와 같이 수정한다.
            return item.get(position);
        }

        //ViewPager에 전개될 Fragment의 개수를 얻어오는 메소드
        @Override
        public int getCount() {
//          return 0;을 아래와 같이 수정한다.
            return item.size();
        }
        //여기까지 클래스 이름 위에서 alt + Enter를 눌러서 자동으로 입력한 FragmentPagerAdapter 추상클래스의 추상메소드 Override

        //TabLayout에 표시할 문자열을 읽어오는 메소드를 Override 한다.
        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {



//            return super.getPageTitle(position);를 아래와 같이 수정한다.
            return title.get(position);
        }
//      Adapter에 TabLayout과 ViewPager에 표시할 데이터를 추가하는 메소드를 만든다.
        public void addItem(String label, Fragment fragment) {
            title.add(label);       //  TabLayout에 표시할 문자열을 추가한다.
            item.add(fragment);     //  ViewPager에 표시할 Fragment를 추가한다.
        }

    }
}










