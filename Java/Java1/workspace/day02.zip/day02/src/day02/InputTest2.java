package day02;

import java.util.Scanner;

public class InputTest2 {
	public static void main(String[] args) {
		String name = "";
//		String lastName = "";
		Scanner sc = new Scanner(System.in);
		
		System.out.print("�̸�  : ");
		name = sc.nextLine();
		
//		name = sc.next();
//		lastName = sc.next();
		
		System.out.println(name + "��");
		
//		System.out.println(name + lastName + "��");
		
	}
}








