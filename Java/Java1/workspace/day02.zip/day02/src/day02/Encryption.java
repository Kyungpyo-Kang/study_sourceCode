package day02;

public class Encryption {
	public static void main(String[] args) {
		String pw = "a1b2c3";
		String en_pw = "";
		
		for (int i = 0; i < pw.length(); i++) {
			en_pw += (char)(pw.charAt(i) * 2);
		}
		
		System.out.println("���� : " + pw);
		System.out.println("��ȣȭ : " + en_pw);
		
	}
}
