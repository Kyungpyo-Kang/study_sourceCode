package day02;

public class CastingTest {
	public static void main(String[] args) {
		
		//�ڵ� ����ȯ
		char data = 65;
		
		System.out.println(10/3);
		System.out.println(10.0/3);
		System.out.println('A' + 3);
		System.out.println('B' + 3);
		System.out.println('C' + 3);
		System.out.println(data);
		System.out.println("================");
		//���� ����ȯ
		System.out.println((double)10/3);
		System.out.println((int)8.43 + 2.59);
		System.out.println((int)(8.43 + 2.59));
		System.out.println((int)8.43 + (int)2.59);
	}
}








