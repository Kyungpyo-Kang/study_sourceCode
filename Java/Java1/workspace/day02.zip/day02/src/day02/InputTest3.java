package day02;

import java.util.Scanner;

public class InputTest3 {
	public static void main(String[] args) {
		
		//���� ����
		int num1 = 0, num2 = 0;
		String oper = "";
		Scanner sc = new Scanner(System.in);
		
		System.out.print("ù��° ����");
		num1 = sc.nextInt();
		
		System.out.print("������ : ");
		sc.nextLine(); // \n
		oper = sc.nextLine();
//		oper = sc.next();
		
		System.out.print("�ι�° ����");
		num2 = sc.nextInt();
		
		System.out.println(num1);
		System.out.println(oper);
		System.out.println(num2);
		
		
		
	}
}










