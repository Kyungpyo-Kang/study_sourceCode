package day02;

public class CastingTest2 {
	public static void main(String[] args) {
		String num1 = "1";
		String num2 = "2";
		String num3 = ""+10.9;
		
		
		int result = Integer.parseInt(num1) + Integer.parseInt(num2);
		
		System.out.println(result);
		System.out.println(Double.parseDouble(num3) + 1);
		
	}
}







