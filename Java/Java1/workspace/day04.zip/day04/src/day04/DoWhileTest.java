package day04;

public class DoWhileTest {
	public static void main(String[] args) {
		
		int cnt = 0;
		
		while(cnt != 0) {
			System.out.println("while�� ����");
		}
		
		do {
			System.out.println("do~while�� ����");
		}while(cnt != 0);
		
		
	}
}
