package day04;

public class ForTest {
	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			System.out.println(10-i+". �ѵ���");
		}
	}
}
