package day04;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class Quiz {
	public static void main(String[] args) {
		
		String qMsg = "Q.���� �� ���α׷��� �� �ƴ� ����?";
		String choiceMsg = "1.C���\n2.JAVA\n3.Python\n4.���վ�\n";
		Scanner sc = new Scanner(System.in);
		int answer = 4;
		int choice = 0;
		
		while(choice != answer) {
			choice = Integer.parseInt(JOptionPane.showInputDialog(qMsg + "\n" + choiceMsg));
			String result = "";
			
			if(choice == answer) {
				result = "����!";
			}else if(choice >= 1 && choice <= 4) {
				result = "����Ф�";
			}else {
				result = "?";
			}
			
			JOptionPane.showMessageDialog(null, result);
			
		}
	}
}








