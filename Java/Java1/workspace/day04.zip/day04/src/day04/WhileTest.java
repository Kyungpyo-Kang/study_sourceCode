package day04;

public class WhileTest {
	public static void main(String[] args) {
		
//		int cnt = 0;
//		
//		while(cnt != 10) {
//			System.out.println("�ѵ���");
//			cnt++;
//		}
		int cnt = 0;
		
		while(true) {
			System.out.println(++cnt);
		}
		
		
	}
}










