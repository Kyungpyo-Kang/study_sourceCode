package day06;

public class MethodTest {
	//f(x) = 2x+1
	//��, x�� �����̴�.
	
	int f(int x) {
		return 2*x+1;
	}
	
	public static void main(String[] args) {
		MethodTest m = new MethodTest();
		int result = m.f(1) + 5;
		System.out.println(result);
	}
}









