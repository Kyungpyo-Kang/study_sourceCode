package day03;

import java.util.Scanner;

public class IfTest {
	public static void main(String[] args) {
		int num1 = 0, num2 = 0;
		int result = 0;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("num1 : ");
		num1 = sc.nextInt();
		
		System.out.print("num2 : ");
		num2 = sc.nextInt();
		
		if(num1 > num2) {
			System.out.println("ū �� : " + num1);
			
		}else if(num1 != num2) {
			System.out.println("ū �� : " + num2);
			
		}else {
			System.out.println("�� ���� �����ϴ�.");
		}
		
		
		
		
	}
}







