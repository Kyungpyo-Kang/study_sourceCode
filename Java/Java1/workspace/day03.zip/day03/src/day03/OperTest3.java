package day03;

public class OperTest3 {
	public static void main(String[] args) {
		int data = 10;
//		data = data + 1;
//		data += 1;
//		System.out.println(++data);
		System.out.println(data--);
		System.out.println(data);
	}
}
