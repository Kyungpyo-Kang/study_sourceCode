package day03;

public class OperTest {
	public static void main(String[] args) {
		//boolean ������ 1byte, (true, false)
		boolean isTrue = 10>1;
		System.out.println(isTrue);
		
		
		System.out.println(10==11 && isTrue);
		System.out.println(10==11 || isTrue);
		System.out.println(!isTrue);
		
		
	}
}
