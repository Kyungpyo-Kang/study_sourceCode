package day05;

public class ArrTest {
	public static void main(String[] args) {
		int[][] arrData = new int[2][3];

		int data = 0;
		
		for (int i = 0; i < arrData.length; i++) {
			for (int j = 0; j < arrData[i].length; j++) {
				data++;
				arrData[i][j] = data; 
			}
		}
		for (int i = 0; i < arrData.length; i++) {
			for (int j = 0; j < arrData[0].length; j++) {
				System.out.println(arrData[i][j]);
			}
		}
	}
}
