package day05;

public class ArTest {
	public static void main(String[] args) {
		int[] arData = new int[5];
		System.out.println(arData);

		for(int i=0; i<arData.length; i++) {
			arData[i] = i+1;
		}

		for(int i=0; i<arData.length; i++) {
			System.out.println(arData[i]);
		}
	}
}
