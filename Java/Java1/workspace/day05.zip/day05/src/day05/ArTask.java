package day05;

public class ArTask {
	public static void main(String[] args) {
		// 1~100������ �� �迭�� �ֱ�
//		int[] arData = new int[100];

//		for (int i = 0; i < arData.length; i++) {
//			arData[i] = i+1;
//		}
//		
//		for (int i = 0; i < arData.length; i++) {
//			System.out.println(arData[i]);
//		}

		// 100~1������ �� �迭�� �ֱ�(100-i)
		// A~F���� �迭�� �ֱ�
//		char[] arData = new char[6];
//		
//		for (int i = 0; i < arData.length; i++) {
//			arData[i] = (char)(65+i);
//		}
//
//		for (int i = 0; i < arData.length; i++) {
//			System.out.println(arData[i]);
//		}

		// A~F�� E�����ϰ� �迭�� �ֱ�
//		char[] arData = new char[5];
//		int temp = 0;
//		
//		for (int i = 0; i < arData.length; i++) {
//			temp = i;
//			
//			if(i == arData.length-1) {
//				temp++;
//			}
//			
//			arData[i] = (char)(temp + 65);
//			
//		}

//		for (int i = 0; i < arData.length; i++) {
//			arData[i] = (char)(i == arData.length-1 ? i+66 : i+65);  
//		}

//		for (int i = 0; i < arData.length; i++) {
//			System.out.println(arData[i]);
//		}

		// aBcDeFgHiJkLmNoPqRsTuVwXyZ �迭�� �ֱ�
		char[] arData = new char[26];

		for (int i = 0; i < arData.length; i++) {
			arData[i] = (char) (i % 2 == 0 ? i + 97 : i + 65);
		}
		
		for (int i = 0; i < arData.length; i++) {
			System.out.print(arData[i]);
		}
		System.out.println();
		
	}
}










