package day07;

class A{
	int data;
	
	A(String name){
		System.out.println(name);
	}
	
	void init(int data) {
		System.out.println("this �ּҰ� : " + this);
		this.data = data;
	}
	
	void printData() {
		//data �տ� this.�� �����Ǿ��ִ�.
		System.out.println(data);
	}
}

public class ClassTest {
	public static void main(String[] args) {
		A obj = new A("�ѵ���");
		A obj2 = new A("ȫ�浿");
		
		System.out.println("obj �ּҰ� : " + obj);
		
		obj.init(50);
//		obj.printData();
		obj2.init(100);
		System.out.println("obj2 �ּҰ� : " + obj2);
		obj2.printData();
	}
}













