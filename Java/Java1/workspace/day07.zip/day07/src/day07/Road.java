package day07;

import javax.swing.JOptionPane;

class Car{
	String brand;
	String color;
	int price;

	
	public Car(String brand, String color, int price) {
		System.out.println("��ü �ʱ�ȭ");
		this.brand = brand;
		this.color = color;
		this.price = price;
	}
	
	public Car(String color, int price) {
		System.out.println("����� ���ݸ� �ʱ�ȭ");
		this.color = color;
		this.price = price;
	}

	void engineStart() {
		System.out.println(brand + " �õ� Ŵ");
	}
	
	void engineStop() {
		System.out.println(brand + " �õ� ��");
	}
	
	void show() {
		System.out.println(brand + ", " + color + ", " + price + "��");
	}
	
}

public class Road {
	public static void main(String[] args) {
		Car momCar = new Car("Black", 8000);
		Car dadyCar = new Car("BMW", "Blue", 7000);
		Car myCar = new Car("Bentley", "White", 35000);
		
		momCar.show();
		dadyCar.show();
		myCar.show();
		
	}
}
















