package day13;

import java.util.ArrayList;
import java.util.Scanner;

public class View {
	public static void main(String[] args) {
		User u = new User();
		int choice = 0;
		Scanner sc = new Scanner(System.in);
		String id = "";
		String pw = "";
		ArrayList<String> user = null;
			
		while(true) {
			System.out.println("1.ȸ������\n2.�α���\n3.������");
			choice = sc.nextInt();
			
			if(choice == 3) break;
			
			if(choice == 1) {
				
				user = new ArrayList<>();
				System.out.print("���̵� : ");
				user.add(sc.next());
				System.out.print("��й�ȣ : ");
				user.add(sc.next());
				
				u.join(user);
				
			}else if(choice == 2) {
				System.out.print("���̵� : ");
				id = sc.next();
				
				System.out.print("�н����� : ");
				pw = sc.next();
				
				u.login(id, pw);
				
			}
			
		}
		
	}
}




