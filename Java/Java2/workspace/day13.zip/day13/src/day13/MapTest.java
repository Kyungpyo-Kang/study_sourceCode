package day13;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class MapTest {
	public static void main(String[] args) {
		HashMap<String, Integer> fruitMap = new HashMap<>();
		ArrayList<Integer> arPrice = new ArrayList<>();
		
		fruitMap.put("���", 1500);
		fruitMap.put("��", 3000);
		fruitMap.put("�ڵ�", 5000);
		fruitMap.put("���", 2000);
		
		System.out.println(fruitMap);
		
		Iterator<Entry<String, Integer>> iter = fruitMap.entrySet().iterator();
		
		while(iter.hasNext()) {
			Entry<String, Integer> entry = iter.next();
			
			System.out.println(entry.getKey() + ", " + entry.getValue() + "��");
		}
		
//		Set<String> s = fruitMap.keySet();
//		Iterator<String> iter = s.iterator();
//		
//		while(iter.hasNext()) {
//			System.out.println(iter.next());
//		}
		
//		for(int price : fruitMap.values()) {
//			System.out.println(price + "��");
//		}

//		fruitMap.values().forEach(value -> arPrice.add(value));
//		System.out.println(arPrice);
//		
//		System.out.println(fruitMap.get("�ڵ�"));
		
	}
}





