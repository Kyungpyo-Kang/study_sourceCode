package day13;

import java.util.HashSet;
import java.util.Iterator;

public class SetTest {
	public static void main(String[] args) {
		HashSet<String> set = new HashSet<>();
		
		set.add("A");
		set.add("AB");
		set.add("O");
		set.add("B");

		set.add("AB");
		set.add("AB");
		set.add("AB");
		set.add("AB");
		set.add("AB");
		set.add("AB");
		set.add("AB");
		
		System.out.println(set);
		
		set.remove("AB");
		System.out.println(set);
		
		Iterator<String> iter = set.iterator();
		
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
	}
}







