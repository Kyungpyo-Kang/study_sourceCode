package day12;

public class HashTest {
	public static void main(String[] args) {
		String str1 = new String("ABC");
		String str2 = "ABC";
		
		System.out.println(str1.hashCode());
		System.out.println(str2.hashCode());
	}
}
