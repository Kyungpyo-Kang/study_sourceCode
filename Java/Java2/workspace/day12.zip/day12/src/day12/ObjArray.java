package day12;

public class ObjArray {
	public static void main(String[] args) {
//		Object[] arData = {
//			new Integer(10),
//			new Boolean(true),
//			new Double(10.231),
//			new String("ABC")
//		};
		Object[] arData = {10, true, 10.231, "ABC"};
		
		for (int i = 0; i < arData.length; i++) {
			System.out.println(arData[i]);
		}
	}
}
