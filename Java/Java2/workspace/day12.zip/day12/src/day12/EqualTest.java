package day12;

import java.util.Random;

public class EqualTest {
	public static void main(String[] args) {
		String str1 = new String("ABC");
		String str2 = "ABC";
		String str3 = "ABC";
		String str4 = new String("ABC");
		Random r1 = new Random();
		Random r2 = new Random();
		
		System.out.println("str1 : " + str1);
		System.out.println("str2 : " + str2);
		System.out.println(str1 == str2);
		System.out.println(str1.equals(str2));
		System.out.println(str2 == str3);
		System.out.println("============================");
		System.out.println(r1.equals(r2));
		r1 = r2;
		System.out.println(r1.equals(r2));
		System.out.println("============================");
		System.out.println(str1.intern() == str2);
		System.out.println(str1.intern() == str4.intern());
		System.out.println(str1.equals(str4));
		
	}
}












