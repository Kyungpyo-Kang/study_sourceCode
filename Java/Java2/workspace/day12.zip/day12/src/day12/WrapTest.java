package day12;

public class WrapTest {
	public static void main(String[] args) {
		int data = 10;
		double data2 = 10.54;
		
		
		//�ڽ�
		Integer wrap_data = new Integer(data);
		Double wrap_data2 = new Double(data2);
		
		//(����) ��ڽ�
		data = wrap_data;
		data2 = wrap_data2;
		
		//���� �ڽ�
		Integer autoData = 10;
		System.out.println(autoData);
		
		
		
	}
}








