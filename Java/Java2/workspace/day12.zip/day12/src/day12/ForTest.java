package day12;

public class ForTest {
	public static void main(String[] args) {
		int[] arData = { 1, 5, 3, 2, 4, 6, 2, 1 };
		
		Object[] arObj = {10, true, 10.231, "ABC"};
		
		for(Object data : arObj) {
			System.out.println(data);
		}
		
//		for(int data : arData) {
//			System.out.println(data);
//		}
	}
}
