package day12;

class GTest<T>{
	
	private T data;

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}
}

public class GClassTest {
	public static void main(String[] args) {
//		GTest<Integer> test = new GTest<>();
//		test.setData(10);
//		System.out.println(test.getData());
		
		GTest test = new GTest();
		test.setData(10.4);
		System.out.println(test.getData());
		
	}
	
}














