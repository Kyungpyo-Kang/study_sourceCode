package day12;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayTest {
	public static void main(String[] args) {
		ArrayList<Integer> arData = new ArrayList<>();
		
		arData.add(10);
		arData.add(80);
		arData.add(90);
		arData.add(30);
		arData.add(20);
		arData.add(50);
		arData.add(40);
		
		System.out.println(arData.size());
		
		System.out.println(arData);
		
		arData.add(0, 100);
		
		System.out.println(arData);
		
		System.out.println(arData.contains(30));
		
		System.out.println(arData.indexOf(1000));
		
		//40�� 400���� �ٲٱ�
		if(arData.contains(40)) {
			arData.set(arData.indexOf(40), 400);
		}else {
			System.out.println("�����ϴ�.");
		}
		System.out.println(arData);
		
		//50 ����
		if(arData.contains(50)) {
			arData.remove(new Integer(50));
		}
		System.out.println(arData);
		
		
		for(int data : arData) {
			System.out.println(data);
		}
		
		Collections.sort(arData);
		System.out.println(arData);
		
		
		
		
	}
}




