package day12;

class GTest2{
	public static <T> T function(T data) {
		T result = null;
		if(data instanceof Integer) {
			result = (T)"����";
		}else if(data instanceof Float || data instanceof Double) {
			result = (T)"�Ǽ�";
		}else if(data instanceof Character) {
			result = (T)"����";
		}else if(data instanceof String) {
			result = (T)"���ڿ�";
		}
		return result;
	} 
}

public class GMethodTest {
	public static void main(String[] args) {
		System.out.println(GTest2.function(10.9));
		System.out.println(GTest2.function('a'));
	}
}














