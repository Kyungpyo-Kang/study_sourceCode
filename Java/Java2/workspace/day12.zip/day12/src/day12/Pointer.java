package day12;

public class Pointer {
	
	static void init(int[] data) {
		data[0] = 30;
	}
	
	public static void main(String[] args) {
		int[] data = {10, 20};
		init(data);
		System.out.println(data[0]);
	}
}









