package day12;

public class GTest3 implements GInter<Double, Integer>{

	@Override
	public Double add(Double data1, Double data2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double sub(Double data1, Integer data2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer mul(Integer data1, Integer data2) {
		// TODO Auto-generated method stub
		return null;
	}

}
