package view;

import dao.userDAO;

public class Index {
	public static void main(String[] args) {
		new userDAO().view();
	}
}
