package dto;

public class carDTO {
	
	private int num;
	private String brand;
	private String color;
	private String option;
	private int maxSpeed;
	private int price;
	
	public carDTO() {}
	
	public carDTO(int num, String brand, String color, String option, int maxSpeed, int price) {
		super();
		this.num = num;
		this.brand = brand;
		this.color = color;
		this.option = option;
		this.maxSpeed = maxSpeed;
		this.price = price;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}

	public int getMaxSpeed() {
		return maxSpeed;
	}

	public void setMaxSpeed(int maxSpeed) {
		this.maxSpeed = maxSpeed;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		String data = num+","+brand+","+color+","+option+","+maxSpeed+","+price; 
		return data;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof carDTO) {
			carDTO c = (carDTO) obj;
			if(c.num == num) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public int hashCode() {
		return num;
	}
	
	
	
}
