package dto;

public class userDTO {
	public static int seq;
	
	private int num;
	private String id;
	private String pw;
	private String name;
	private String birth;
	private String gender;
	
	public userDTO() {}
	
	public userDTO(String id, String pw, String name, String birth, String gender) {
		super();
		this.num = ++seq;
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.birth = birth;
		this.gender = gender;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	
	@Override
	public String toString() {
		String data = id+","+name+","+birth+","+gender;
		return data;
	}
	
	@Override
	public int hashCode() {
		return num;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof userDTO) {
			userDTO u = (userDTO) obj;
			if(u.num == num) {
				return true;
			}
		}
		return false;
	}
	
	
	
	
	
}
