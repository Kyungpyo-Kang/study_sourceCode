package dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import dto.carDTO;
import dto.userDTO;

public class Connecter {
	HashMap<userDTO, carDTO> DB = new HashMap<>();
	
	public void insert(userDTO user, carDTO car) {
		DB.put(user, car);
	}
	public void update(userDTO user, carDTO car) {
		DB.remove(user);
		insert(user, car);
	}
	public void delete(userDTO user) {
		DB.remove(user);
	}
	public HashMap<userDTO, carDTO> select() {
		return DB;
	}
	public Set<Entry<userDTO, carDTO>> select(String keyword) {
		Set<Entry<userDTO, carDTO>> resultSet = new HashSet<>();
		Iterator<Entry<userDTO, carDTO>> iter = DB.entrySet().iterator();
		while(iter.hasNext()) {
			Entry<userDTO, carDTO> entry = iter.next();
			
			for (int i = 0; i < DB.size(); i++) {
				String[] arUser = entry.getKey().toString().split(",");
				String[] arCar = entry.getValue().toString().split(",");
				for(String data : arUser) {
					if(data.equals(keyword)) {
						resultSet.add(entry);
					}
				}
				for(String data : arCar) {
					if(data.equals(keyword)) {
						resultSet.add(entry);
					}
				}
			}
		}
		return resultSet;
	}
}
