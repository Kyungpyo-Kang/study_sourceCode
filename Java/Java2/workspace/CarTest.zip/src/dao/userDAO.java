package dao;

import java.util.Iterator;
import java.util.Map.Entry;

import dto.carDTO;
import dto.userDTO;

public class userDAO {
	
	Connecter c = new Connecter();
	
	public void insert(userDTO user, carDTO car) {
		c.insert(user, car);
	}
	public void updateUser(userDTO user) {
		Iterator<userDTO> iter = c.select().keySet().iterator();
		
		while(iter.hasNext()) {
			userDTO temp = iter.next();
			if(temp.getNum() == user.getNum()) {
				c.update(user, c.select().get(temp));
			}
		}
	}
	public void updateCar(userDTO user, carDTO car) {
		Iterator<userDTO> iter = c.select().keySet().iterator();
		
		while(iter.hasNext()) {
			userDTO temp = iter.next();
			if(temp.getNum() == user.getNum()) {
				c.update(user, car);
			}
		}
	}
	public boolean delete(userDTO user) {
		boolean check = false;
		Iterator<userDTO> iter = c.select().keySet().iterator();
		
		while(iter.hasNext()) {
			userDTO temp = iter.next();
			if(temp.getId().equals(user.getId())) {
				if(temp.getPw().equals(user.getPw())) {
					c.delete(user);
					check = true;
				}
			}
		}
		return check;
	}
	public String selectAll() {
		Iterator<Entry<userDTO, carDTO>> iter = c.select().entrySet().iterator();
		String msg = getFrontFrame(iter);
		return msg.equals("") ? "��� ����" : msg;
	}
	
	public userDTO selectUser(String id, String pw) {
		Iterator<userDTO> iter = c.select().keySet().iterator();
		userDTO user = null;
		while(iter.hasNext()) {
			userDTO temp = iter.next();
			if(temp.getId().equals(id)) {
				if(temp.getPw().equals(pw)) {
					user = temp;
				}
			}
		}
		return user;
	}
	
	
	
	
	
	public String select(String keyword) {
		Iterator<Entry<userDTO, carDTO>> iter = c.select(keyword).iterator();
		String msg = getFrontFrame(iter);
		return msg.equals("") ? "�˻���� ����" : msg;
	}
	
	public String getFrontFrame(Iterator<Entry<userDTO, carDTO>> iter) {
		String list = "";
		
		String[] arUserTitle = {"���̵�","�̸�","�������","����"};
		String[] arCarTitle = {"������ȣ","�귣��","����","�ɼ�","�ִ�ü�","����"};
		
		while(iter.hasNext()) {
			Entry<userDTO, carDTO> entry = iter.next();
			String[] arUser = entry.getKey().toString().split(",");
			String[] arCar = entry.getValue().toString().split(",");
			
			
			list += "-------------ȸ������-------------\n";
			for (int i = 0; i < arUser.length; i++) {
				list += arUserTitle[i]+" : "+arUser[i] + "\n";
			}
			list += "-------------��������-------------\n";
			for (int i = 0; i < arCar.length; i++) {
				list += arCarTitle[i]+" : "+arCar[i] + "\n";
			}
		}
		return list;
	}
	
	public void view() {
		
	}
}
