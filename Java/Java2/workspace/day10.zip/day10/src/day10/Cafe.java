package day10;

public interface Cafe {
	
	String[] getMenu();
	int[] getPrice();
	void sell(String choice);
	
}
