package day10;

public abstract class StoreAdapter implements Store {
	@Override
	public String[] getMenu() {
		return null;
	}
	
	@Override
	public int[] getPrice() {
		return null;
	}
	
	@Override
	public void sell(String choice) {}
	
}
