package day10;

public class DStore {
	public static void main(String[] args) {

		// ����
		Gucci gangnam = new Gucci();

		// ���
		Gucci jamsil = new Gucci();

		gangnam.regist(new Store() {

			@Override
			public void sell(String choice) {
				for (int i = 0; i < getMenu().length; i++) {
					if (getMenu()[i].equals(choice)) {
						System.out.println(choice + "�ֹ� �Ϸ�");
						System.out.println("���� : " + getPrice()[i]);
					}
				}
			}

			@Override
			public int[] getPrice() {
				int[] arPrice = { 600000, 1500000, 2000000 };
				return arPrice;
			}

			@Override
			public String[] getMenu() {
				String[] arMenu = { "����", "����", "�ð�" };
				return arMenu;
			}
		});

		jamsil.regist(new StoreAdapter() {
			@Override
			public String[] getMenu() {
				String[] arMenu = { "���", "����", "����" };
				return arMenu;
			}

			@Override
			public void sell(String choice) {
				for (int i = 0; i < getMenu().length; i++) {
					if (getMenu()[i].equals(choice)) {
						System.out.println(choice + "���� ����");
						System.out.println("������� ���ƾ��.");
					}
				}
			}
		});

	}
}
