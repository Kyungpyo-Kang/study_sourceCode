package day10;

public class Frozen extends Video implements AnimationMarker{
	@Override
	public String toString() {
		return "�ܿ�ձ�";
	}
}
