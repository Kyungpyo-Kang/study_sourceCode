package day10;

public class ZZangu extends Video implements AnimationMarker{
	@Override
	public String toString() {
		return "¯��";
	}
}
