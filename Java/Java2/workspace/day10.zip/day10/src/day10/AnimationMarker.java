package day10;

public interface AnimationMarker {}
