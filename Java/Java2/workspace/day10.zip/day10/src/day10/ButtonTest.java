package day10;

import java.awt.Button;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class ButtonTest extends Frame{
	public ButtonTest() {
		super("��ư �׽�Ʈ");
		setSize(300, 300);
		
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (d.width - this.getWidth()) / 2;
		int y = (d.height - this.getHeight()) / 2;
		
		setLocation(x, y);
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		
		Button btn = new Button("�����ּ��� ��!");
		
		btn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				System.out.println(e.getX());
				System.out.println(e.getY());
				System.out.println("������.");
			}
		});
		
		add(btn);
		
		
		setVisible(true);
		
	}
	
	public static void main(String[] args) {
		new ButtonTest();
	}
}









