package day10;

public class StarBucks{
	String[] arMenu = new String[5];
	int[] arPrice = new int[5];
	
	void regist(Cafe c) {
		System.out.println("--------�� ����--------");
		arMenu = c.getMenu();
		arPrice = c.getPrice();
		for (int i = 0; i < arMenu.length; i++) {
			System.out.println(i + 1 + ". " + arMenu[i]);
		}
		
		c.sell("�Ƹ޸�ī��");
		
	}
}
