package day10;

public class TV {
	
	static void checkAni(Video[] arVideo) {
		for (int i = 0; i < arVideo.length; i++) {
			if(arVideo[i] instanceof AnimationMarker) {
				System.out.println(arVideo[i] + "�� �ִϸ��̼� �Դϴ�.");
			}else {
				System.out.println(arVideo[i] + "�� ��ȭ�Դϴ�.");
			}
		}
	}
	
	
	public static void main(String[] args) {
		//up casting
		Video[] arVideo = {
				new ZZangu(),
				new Doraemong(),
				new Onepiece(),
				new Frozen(),
				new Terminator()
		};
		
		checkAni(arVideo);
	}
}





