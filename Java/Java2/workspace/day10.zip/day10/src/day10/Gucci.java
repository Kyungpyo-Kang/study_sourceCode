package day10;

public class Gucci {
	String[] arMenu = new String[3];
	int[] arPrice = new int[3];

	// �������̽�
	void regist(Store s) {
		arMenu = s.getMenu();
		arPrice = s.getPrice();
		for (int i = 0; i < arMenu.length; i++) {
			System.out.println(i+1+". " + arMenu[i]);
		}

		s.sell("����");
		
	}
	// �߻�Ŭ����
	void regist(StoreAdapter s) {
		arMenu = s.getMenu();
		
		for (int i = 0; i < arMenu.length; i++) {
			System.out.println(i+1+". " + arMenu[i]);
		}
		
		s.sell("����");
		
	}
}











