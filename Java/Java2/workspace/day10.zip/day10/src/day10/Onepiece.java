package day10;

public class Onepiece extends Video implements AnimationMarker{
	@Override
	public String toString() {
		return "���ǽ�";
	}
}
