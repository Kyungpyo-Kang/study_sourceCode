package day10;

public class Downtown {
	public static void main(String[] args) {
		StarBucks gangnam = new StarBucks();
		String[] arMenu = {"�Ƹ޸�ī��", "ī���", "�׸�Ƽ", "������", "���� ����ũ"};
		int[] arPrice = {1500, 2000, 3000, 3500, 5500};
		
		gangnam.regist(new Cafe() {
			
			@Override
			public void sell(String choice) {
				System.out.println("---------------------");
				for (int i = 0; i < arMenu.length; i++) {
					if(getMenu()[i].equals(choice)) {
						System.out.println(getMenu()[i] + " �ֹ� ����");
						System.out.println("���� : " + arPrice[i]);
					}
				}
			}
			
			@Override
			public int[] getPrice() {
				return arPrice;
			}
			
			@Override
			public String[] getMenu() {
				return arMenu;
			}
		});
		
		
	}
}
