package day10;

public class Terminator extends Video {
	@Override
	public String toString() {
		return "�͹̳�����";
	}
}
