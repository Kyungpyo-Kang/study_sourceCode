package boxOffice;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class SearchFrame extends JFrame {
	public SearchFrame(String result) {
		super("�˻� ���");
		Font f = new Font("����ü", Font.BOLD, 20);
		JTextArea resultArea = new JTextArea(result);
		JScrollPane resultScroll = new JScrollPane();
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		setSize(400, 600);
		int x = (d.width - getWidth()) / 2;
		int y = (d.height - getHeight()) / 2;
		setLocation(x, y);
		
		resultArea.setFont(f);
		resultScroll.setViewportView(resultArea);
		
		add(resultScroll);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);
		setVisible(true);
		
	}
}







