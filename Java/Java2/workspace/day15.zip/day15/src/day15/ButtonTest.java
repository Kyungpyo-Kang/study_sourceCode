package day15;

import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JFrame;

public class ButtonTest extends JFrame implements ActionListener{
	Button[] arBtn = new Button[16];
	
	public ButtonTest() {
		super("��ư �׽�Ʈ");
		setSize(500, 500);
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		
		int x = (d.width - getWidth()) / 2;
		int y = (d.height - getHeight()) / 2;
		
		setLocation(x, y);
		setLayout(new GridLayout(4, 4));
		
		for (int i = 0; i < arBtn.length; i++) {
			arBtn[i] = new Button(i+1+"");
			arBtn[i].setName(i+1+"�� ��ư");
			arBtn[i].addActionListener(this);
			add(arBtn[i]);
		}
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	public static void main(String[] args) {
		new ButtonTest();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		Button btn = (Button)e.getSource();
		for (int i = 0; i < arBtn.length; i++) {
			if(e.getActionCommand().equals(i+1+"")) {
				Color c = new Color(new Random().nextInt(16777217));
				arBtn[i].setBackground(c);
//				System.out.println(i+1);
//				System.out.println(btn.getName());
			}
		}
	}
	
}










