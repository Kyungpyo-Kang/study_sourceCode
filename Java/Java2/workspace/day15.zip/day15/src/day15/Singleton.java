package day15;

public class Singleton {
	private Singleton() {}
	
	public static Singleton getInstance() {
		
		Singleton s = new Singleton();
		
		return s;
		
	}
	
}
