package day15;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JLabel;

public class WindowTest4 extends Frame{
	
	Label l1 = new Label("CAT");
	Label l2 = new Label("DOG");
	Label l3 = new Label("�۾���");
	JLabel l4 = new JLabel("�⸰");
	
	public WindowTest4() {
		super("FlowLayout");
		setSize(300, 500);
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		
		int x = (d.width - getWidth()) / 2;
		int y = (d.height - getHeight()) / 2;
		
		setLocation(x, y);
		setLayout(new FlowLayout());
		
		//Label���� ��밡���� �۾�ü
		//Serif, SansSerif, Monospaced, Dialog, DialogInput
		//style
		//Font.BOLD : ����
		//Font.ITALIC : ����
		//Font.PLAIN : ����
		
		Font f = new Font("Serif", Font.BOLD, 30);
		
		l1.setBackground(Color.RED);
		l1.setForeground(Color.YELLOW);
		l1.setAlignment(Label.CENTER);
		l1.setFont(f);
		
		//JLabel�� ����� �������� �ʵ��� �����ϴ� ���
		l4.setOpaque(true);
		l4.setBackground(Color.BLACK);
		l4.setForeground(Color.WHITE);
		l4.setHorizontalAlignment(JLabel.CENTER);
		l4.setVerticalAlignment(JLabel.TOP);
		l4.setFont(f);
		l4.setPreferredSize(new Dimension(100, 100));

		add(l1);
		add(l2);
		add(l3);
		add(l4);
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		//â ũ�� ���� �Ұ�(ũ�� ����)
		setResizable(false);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new WindowTest4();
	}
}




