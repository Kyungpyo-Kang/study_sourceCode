package day15;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;

import javax.swing.JFrame;

public class WindowTest3 extends JFrame{
	
	public WindowTest3() {
		super("���߾�");
		setSize(400, 400);
		getContentPane().setBackground(Color.YELLOW);
		//���� ��ġ�� �ػ󵵸� �����´�.
//		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		
		//â�� ȭ�� �� ����� ǥ���Ѵ�.
//		int x = (d.width - getWidth()) / 2;
//		int y = (d.height - getHeight()) / 2;
//		setLocation(x, y);

		//â���
		setTitle("â���");
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice gd = ge.getDefaultScreenDevice();
		
		//��üȭ��
		setUndecorated(true);
		
		gd.setFullScreenWindow(this);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new WindowTest3();
	}
}







