package day15;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Panel;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class BorderLayoutTest extends JFrame{
	
	JLabel l1 = new JLabel("1");
	JLabel l2 = new JLabel("2");
	JLabel l3 = new JLabel("3");
	JLabel l4 = new JLabel("4");
	JLabel l5 = new JLabel("5");
	//�г��� �����.
	Panel p = new Panel(new BorderLayout());
	//l6�� �����.
	JLabel l6 = new JLabel("6");
	//�гο� BorderLayout()�� �ش�.
	//�гο� l4�� NORTH�� �߰��Ѵ�.
	//�гο� l6�� �߰��Ѵ�.
	//�����ӿ� �г��� CENTER�� �߰��Ѵ�.
	
	public BorderLayoutTest() {
		super("Border Layout");
		setSize(600, 600);
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		
		int x = (d.width - getWidth()) / 2;
		int y = (d.height - getHeight()) / 2;
		
		setLocation(x, y);
		setLayout(new BorderLayout());
		
		l1.setOpaque(true);
		l2.setOpaque(true);
		l3.setOpaque(true);
		l4.setOpaque(true);
		l5.setOpaque(true);
		l6.setOpaque(true);
		//JLabel�� �پ��� �۲��� �����Ѵ�.
		
		Font f = new Font("����ü", Font.BOLD, 30);
		
		l1.setFont(f);
		l2.setFont(f);
		l3.setFont(f);
		l4.setFont(f);
		l5.setFont(f);
		l6.setFont(f);
		
		l1.setHorizontalAlignment(JLabel.CENTER);
		l2.setHorizontalAlignment(JLabel.CENTER);
		l3.setHorizontalAlignment(JLabel.CENTER);
		l4.setHorizontalAlignment(JLabel.CENTER);
		l5.setHorizontalAlignment(JLabel.CENTER);
		l6.setHorizontalAlignment(JLabel.CENTER);
		
		l1.setBackground(Color.BLUE);
		l2.setBackground(Color.YELLOW);
		l3.setBackground(Color.MAGENTA);
		l4.setBackground(Color.GRAY);
		l5.setBackground(Color.GREEN);
		l6.setBackground(Color.ORANGE);
		
		l1.setPreferredSize(new Dimension(getWidth(), 100));
		l2.setPreferredSize(new Dimension(100, getHeight()));
		l3.setPreferredSize(new Dimension(100, getHeight()));
		l4.setPreferredSize(new Dimension(getWidth() - l2.getWidth() * 2, 180));
		l5.setPreferredSize(new Dimension(getWidth(), 100));
		
		p.add(l4, BorderLayout.NORTH);
		p.add(l6);
		
		add(l1, BorderLayout.NORTH);
		add(l2, BorderLayout.WEST);
		add(l3, BorderLayout.EAST);
		add(p, BorderLayout.CENTER);
		add(l5, BorderLayout.SOUTH);
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
	}
	
	public static void main(String[] args) {
		new BorderLayoutTest();
	}
	
}






