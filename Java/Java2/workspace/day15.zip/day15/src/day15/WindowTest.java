package day15;

import java.awt.Color;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class WindowTest extends Frame{
	
	public WindowTest() {
		super("Sub Frame");
//		setSize(200, 200);
//		setLocation(600, 300);
		setBounds(600, 300, 200, 200);
		setBackground(Color.PINK);
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				dispose();
			}
		});
		
		setVisible(true);
	}
	
	
	public static void main(String[] args) {
		Frame window = new Frame("Frame Test");
		window.setSize(400, 400);
		window.setLocation(800, 300);
		
		window.setBackground(Color.ORANGE);
		
		window.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		
		window.setVisible(true);
		new WindowTest();
		
	}
}
