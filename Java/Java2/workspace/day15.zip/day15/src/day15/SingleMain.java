package day15;


public class SingleMain {
	public static void main(String[] args) {
		Singleton s = Singleton.getInstance();
	}
}
