package vo;

public class StudentVO {
	//��ȣ, �̸�, ����
	private int num;
	private String name;
	private int age;
	private static int idx;
	//������ : alt + shift + s + o
	public StudentVO() {}
	
	public StudentVO(String name, int age) {
		this.num = ++idx;
		this.name = name;
		this.age = age;
	}

	//getter, setter : alt + shift + s + r
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	@Override
	public String toString() {
		return num + "��, " + name + ", " + age + "��";
	}
}










