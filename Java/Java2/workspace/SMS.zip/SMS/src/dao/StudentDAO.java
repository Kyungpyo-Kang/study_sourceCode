package dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Map.Entry;

import vo.StudentVO;

public class StudentDAO {
	
	//�����
	//Ű : �л� ��ü
	//�� : ���� ���� ���� ����
	HashMap<StudentVO, ArrayList<Integer>> stdMap = new HashMap<>();
	String[] arSub = {"����", "����", "����"};
	StudentVO std;
	
	void insert(StudentVO std, ArrayList<Integer> arScore) {
		stdMap.put(std, arScore);
		System.out.println("��� �Ϸ�");
 	}
	
	void update() {}
	
	void delete(String name) {
		ArrayList<StudentVO> arStd = checkDup(name);
		
		if(arStd.size() == 1) {
			stdMap.remove(arStd.get(0));
			
		}else if(arStd.size() == 0) {
			System.out.println("������ �л��� �����ϴ�.");
			
		}else {
			
			for(StudentVO std : arStd) {
				System.out.println(std);
			}
			
			System.out.print("�����Ͻ� �л� ��ȣ : ");
			int num = new Scanner(System.in).nextInt();
			
			if(select(num)) {
				stdMap.remove(this.std);
			}else {
				System.out.println("���� ��ȣ�Դϴ�.");
			}
		}
		
	}
	
	ArrayList<StudentVO> checkDup(String name) {
		ArrayList<StudentVO> arStd = new ArrayList<>();
		
		Iterator<StudentVO> iter = stdMap.keySet().iterator();
		
		while(iter.hasNext()) {
			StudentVO temp = iter.next();
			if(temp.getName().equals(name)) {
				arStd.add(temp);
			}
		}
		return arStd;
	}
	
	void select(String name) {
		
		Iterator<StudentVO> iter = stdMap.keySet().iterator();
		
		while(iter.hasNext()) {
			StudentVO temp = iter.next();
			if(temp.getName().equals(name)) {
				System.out.println(temp);
				
				int cnt = 0;
				for(int score : stdMap.get(temp)) {
					System.out.println(arSub[cnt] + " : " + score + "��");
					cnt++;
				}
			}
		}
		
	}
	
	boolean select(int num) {
		
		Iterator<StudentVO> iter = stdMap.keySet().iterator();
		boolean check = false;
		while(iter.hasNext()) {
			StudentVO temp = iter.next();
			if(temp.getNum() == num) {
				std = temp;
				check = true;
			}
		}
		return check;
	}
	
	void show() {
		Iterator<Entry<StudentVO, ArrayList<Integer>>> iter = stdMap.entrySet().iterator();
		
		while(iter.hasNext()) {
			Entry<StudentVO, ArrayList<Integer>> en = iter.next();
			
			System.out.println(en.getKey());
			int cnt = 0;
			for(int score : en.getValue()) {
				System.out.println(arSub[cnt] + " : " + score + "��");
				cnt++; 
			}
		}
		
	}
	
	void view() {}
}










