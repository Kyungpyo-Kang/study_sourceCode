package dto;

//Model
public class UserDTO {
	
	private static int seq; 
	
	private int num;
	private String id;
	private String pw;
	private String name;
	private String birth;
	private String gender;
	
	public UserDTO() {}
	
	public UserDTO(String id, String pw, String name, String birth, String gender) {
		super();
		this.num = ++seq;
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.birth = birth;
		this.gender = gender;
	}
	
	public UserDTO(String[] arData) {
		super();
		this.num = ++seq;
		this.id = arData[0];
		this.pw = arData[1];
		this.name = arData[2];
		this.birth = arData[3];
		this.gender = arData[4];
	}
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	@Override
	public String toString() {
		String data = id +","+name+","+birth+","+gender;
		return data;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof UserDTO) {
			UserDTO u = (UserDTO) obj;
			if(u.num == num) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public int hashCode() {
		return num;
	}
}










