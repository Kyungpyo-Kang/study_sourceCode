package day11;

public abstract class Lift {
	static int floor;
	
	abstract void up();
	abstract void down();
	abstract void stop();
	abstract void start(int choice);
	abstract void go();
}
