package day11;

import java.util.Random;
import java.util.Scanner;

public class Building {
	public static void main(String[] args) {
		Elevator elevator = new Elevator();
		Random r = new Random();
		int[] arElevator = new int[5];
		int cnt = 0;
		
		cnt = r.nextInt(6);
		
		for (int i = 0; i < cnt; i++) {
			arElevator[i] = 1;
		}
		
		//-3 ~ 10
		//max - min + 1 : 14 + min
		//0 ~ 13 - 3
		while(true) {
			Elevator.floor = r.nextInt(elevator.maxFloor - elevator.minFloor + 1) + elevator.minFloor;
			if(Elevator.floor != 0) break;
		}
		System.out.println("���� ž�� �ο� : " + cnt + "��");
		System.out.println("Y : Ÿ��            N : ������");
		
		if(new Scanner(System.in).next().toUpperCase().equals("Y")) {
			try {
				arElevator[cnt] = 1;
				elevator.go();
			} catch (Exception e) {
				System.out.println("���� �ʰ�");
			}
		}		
	}
}









