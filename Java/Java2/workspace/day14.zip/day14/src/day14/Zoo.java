package day14;

public class Zoo {
	public static void main(String[] args) {
		Runnable r1 = new Pig("�ܲ�");
		Runnable r2 = new Dog("�۸�");
		Runnable r3 = new Cat("�߿�");
		
		Thread[] animal = {
				new Thread(r1),
				new Thread(r2),
				new Thread(r3),
		};
		
		for (int i = 0; i < animal.length-1; i++) {
			animal[i].start();
		}
		try {
			animal[0].join();
			animal[1].join();
		} catch (InterruptedException e) {}
		
		animal[2].start();
		
	}
}




