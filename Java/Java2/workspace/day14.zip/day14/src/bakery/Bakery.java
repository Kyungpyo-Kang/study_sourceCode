package bakery;

import javax.swing.JOptionPane;

public class Bakery {
	public static void main(String[] args) {
		BreadPlate bread = new BreadPlate();
		BreadMaker maker = new BreadMaker(bread);
		
		String[] arMenu = {"���Ա�", "�� �Ծ����!"};
		int choice = 0;
		
		Thread t = new Thread(maker);
		t.start();
		while(true) {
			choice = JOptionPane.showOptionDialog(null, "", "����", JOptionPane.DEFAULT_OPTION,
					JOptionPane.PLAIN_MESSAGE, null, arMenu, null);
			
			if(choice == -1 || choice == 1) break;
			
			bread.eatBread();
		}
	}
}












