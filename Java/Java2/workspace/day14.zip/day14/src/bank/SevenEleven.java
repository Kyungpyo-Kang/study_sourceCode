package bank;

public class SevenEleven {
	public static void main(String[] args) {
		ATM cityBank = new ATM();
		
		Thread mom = new Thread(cityBank, "����");
		Thread son = new Thread(cityBank, "�Ƶ�");
		
		mom.start();
		son.start();
	}
}









