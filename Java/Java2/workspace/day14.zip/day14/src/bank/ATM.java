package bank;

public class ATM implements Runnable{

	int money = 10000;
	
	public void withdraw(int money) {
		this.money -= money;
		System.out.println(Thread.currentThread().getName() + "��(��)" + money + "�� ���");
	}
	
	@Override
	public void run() {
		for (int i = 0; i < 5; i++) {
			synchronized (this) {
				withdraw(1000);
				System.out.println("���� �ܾ� : " + this.money + "��");
			}
			try {Thread.sleep(1000);} catch (InterruptedException e) {}
		}
	}
}







