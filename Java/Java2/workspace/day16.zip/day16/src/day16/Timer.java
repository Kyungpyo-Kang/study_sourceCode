package day16;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Timer extends JFrame implements ActionListener, Runnable{

	JButton start = new JButton("����");
	JButton pause = new JButton("�Ͻ�����");
	JButton reset = new JButton("�ʱ�ȭ");
	
	long s, e;
	
	boolean flag;
	
	SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
	
	public Timer() {
		super("Ÿ�̸�");
		setSize(300, 500);
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (d.width - getWidth()) / 2;
		int y = (d.height - getHeight()) / 2;
		
		setLocation(x, y);
		//*�е� : ����
		//new GridLayout(��, ��, �����е�, �����е�);
		setLayout(new GridLayout(3, 1, 10, 10));
		//����, ���ڻ�, ��Ʈ(�۲�, ��Ÿ��, ũ��)
		
		Font f = new Font("�ü�ü", Font.BOLD, 40);
		
		start.setBackground(Color.BLACK);
		start.setForeground(Color.WHITE);
		start.setFont(f);
		
		pause.setBackground(Color.BLACK);
		pause.setForeground(Color.WHITE);
		pause.setFont(f);
		
		reset.setBackground(Color.BLACK);
		reset.setForeground(Color.WHITE);
		reset.setFont(f);
		
		start.addActionListener(this);
		pause.addActionListener(this);
		reset.addActionListener(this);
		
		add(start);
		add(pause);
		add(reset);
		
		pause.setEnabled(false);
		reset.setEnabled(false);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
	}
	
	
	@Override
	public void run() {
		if(s == 0) {
			s = System.currentTimeMillis();
			e = s;
		}
		
		while(true) {
			long time = 6000 - ((e += 11) - s) - 32400000;
			setTitle(sdf.format(time));
			
			try {Thread.sleep(10);} catch (InterruptedException e1) {;}
			
			if(flag) break;
			
			if(getTitle().equals("00:00:00")) {
				JOptionPane.showMessageDialog(this, "Ÿ�ӿ���");
				dispose();
				new Timer();
				break;
				
			}
			
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Thread t = new Thread(this);
		
		switch(e.getActionCommand()) {
		case "����":
			t.start();
			start.setEnabled(false);
			pause.setEnabled(true);
			reset.setEnabled(false);
			flag = false;
			break;
		case "�Ͻ�����":
			start.setEnabled(true);
			pause.setEnabled(false);
			reset.setEnabled(true);
			flag = true;
			break;
		case "�ʱ�ȭ":
			start.setEnabled(true);
			pause.setEnabled(false);
			reset.setEnabled(false);
			flag = false;
			s = 0;
			setTitle(sdf.format(-32395000));
			break;
		}
	}
	
	public static void main(String[] args) {
		new Timer();
	}
	
}
