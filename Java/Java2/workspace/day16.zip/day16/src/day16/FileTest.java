package day16;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileTest {
	public static void main(String[] args) throws IOException{
		BufferedWriter bw = new BufferedWriter(new FileWriter("test.txt"));
		BufferedReader br = null;
		String result = "";
		try {
			br = new BufferedReader(new FileReader("test.txt"));
		} catch (FileNotFoundException e) {
			System.out.println("������ �����ϴ�.");
		}
		
		bw.write("���\n");
		bw.write("����\n");
		bw.write("�ູ\n");
		bw.close();
		
		while(true) {
			String temp = br.readLine();
			if(temp == null) {
				break;
			}
			result += temp + "\n";
		}
	
	//��� �߰��ϱ�
		result += "���\n";
		
		BufferedWriter bw2 = new BufferedWriter(new FileWriter("test.txt"));
		bw2.write(result);
		bw2.close();
		
		try {
			br = new BufferedReader(new FileReader("test.txt"));
		} catch (FileNotFoundException e) {
			System.out.println("������ �����ϴ�.");
		}
		
//		while(true) {
//			String temp = br.readLine();
//			if(temp == null) {
//				break;
//			}
//			System.out.println(temp);
//		}
		
		//������ �г�� ����
		result = "";
		while(true) {
			String temp = br.readLine();
			if(temp == null) break;
			
			if(temp.equals("����")) {
				result += "�г�\n";
			}else {
				result += temp + "\n";
			}
		}
		bw2 = new BufferedWriter(new FileWriter("test.txt"));
		bw2.write(result);
		bw2.close();
		
		try {
			br = new BufferedReader(new FileReader("test.txt"));
		} catch (FileNotFoundException e) {
			System.out.println("������ �����ϴ�.");
		}

		while(true) {
			String temp = br.readLine();
			if(temp == null) {
				break;
			}
			System.out.println(temp);
		}
	}
}











