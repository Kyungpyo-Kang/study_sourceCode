package day09;

public interface InterTest {
	int data = 10;
	
	abstract void showData();
	void getData();
	
	
}
