package day09;

public abstract class Army implements Soldier{
	@Override
	public void eat() {}
	
	@Override
	public void sleep() {}
	
	@Override
	public void work() {}
	
	@Override
	public void hello() {}
}
