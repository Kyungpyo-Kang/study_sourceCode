package day09;

public interface Soldier {
	int arm = 2;
	int leg = 2;
	
	void eat();
	void sleep();
	void work();
	void hello();
	
}









