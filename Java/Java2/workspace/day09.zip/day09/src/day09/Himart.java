package day09;

public class Himart {
	public static void main(String[] args) {
		TV oled = new TV();
		Airfrier philips = new Airfrier();
		
		oled.powerOn();
		oled.powerOn();
		
		philips.powerOn();
		philips.powerOn();
		philips.powerOff();
		philips.powerOff();
	}
}
