package day09;


public class ClassTest implements InterTest{

	@Override
	public void showData() {
		
	}

	@Override
	public void getData() {
		
	}
	
}
